import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AccountCard } from "@/components/account-card";
import { RentalModal } from "@/components/rental-modal";
import { PaymentModal } from "@/components/payment-modal";
import { SuccessModal } from "@/components/success-modal";
import { AdminLoginModal } from "@/components/admin-login-modal";
import { useLocation } from "wouter";
import { Shield, ExternalLink } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const [selectedAccountId, setSelectedAccountId] = useState<number | null>(null);
  const [showRentalModal, setShowRentalModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [paymentData, setPaymentData] = useState<any>(null);
  const [rentalResult, setRentalResult] = useState<any>(null);

  const { data: availableAccounts, refetch: refetchAvailable } = useQuery({
    queryKey: ["/api/accounts/available"],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  const { data: rentedAccounts, refetch: refetchRented } = useQuery({
    queryKey: ["/api/accounts/rented"],
    refetchInterval: 10000 // Refresh every 10 seconds
  });

  const { data: pricing } = useQuery({
    queryKey: ["/api/pricing"]
  });

  const handleRentAccount = (accountId: number) => {
    setSelectedAccountId(accountId);
    setShowRentalModal(true);
  };

  const handlePackageSelected = (packageType: string) => {
    // This will be called from RentalModal
    setShowRentalModal(false);
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = (result: any) => {
    setShowPaymentModal(false);
    setRentalResult(result);
    setShowSuccessModal(true);
    refetchAvailable();
    refetchRented();
  };

  const handleAdminLogin = () => {
    setShowAdminModal(false);
    setLocation("/admin");
  };

  return (
    <div className="min-h-screen bg-gray-50 font-inter">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary">Thuetool.online</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => setShowAdminModal(true)}
                className="text-gray-600 hover:text-primary"
              >
                <Shield className="w-4 h-4 mr-2" />
                Admin
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-blue-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Thuetool.online</h2>
          <p className="text-xl mb-2">Cho thuê tài khoản UnlockTool, Chimera giá rẻ</p>
          <p className="text-lg opacity-90">
            Thuê Chimera vui lòng liên hệ{" "}
            <a
              href="https://zalo.me/0325882520"
              className="underline hover:text-blue-200 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              Zalo <ExternalLink className="inline w-4 h-4" />
            </a>
          </p>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Available Accounts Section */}
        <div className="mb-8">
          <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
            <div className="w-6 h-6 bg-secondary rounded-full flex items-center justify-center mr-3">
              <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
            Tài khoản sẵn sàng
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableAccounts?.map((account: any, index: number) => (
              <AccountCard
                key={account.id}
                account={{
                  ...account,
                  displayName: `Tài khoản No.${index + 1}`
                }}
                onRent={() => handleRentAccount(account.id)}
              />
            ))}
          </div>

          {(!availableAccounts || availableAccounts.length === 0) && (
            <Card>
              <CardContent className="text-center py-8">
                <p className="text-gray-500">Hiện tại không có tài khoản nào khả dụng</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Rented Accounts Section */}
        <div className="mb-8">
          <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
            <div className="w-6 h-6 bg-warning rounded-full flex items-center justify-center mr-3">
              <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
            Tài khoản đang cho thuê
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rentedAccounts?.map((account: any, index: number) => {
              const availableCount = availableAccounts?.length || 0;
              return (
                <AccountCard
                  key={account.id}
                  account={{
                    ...account,
                    displayName: `Tài khoản No.${availableCount + index + 1}`
                  }}
                  isRented
                />
              );
            })}
          </div>

          {(!rentedAccounts || rentedAccounts.length === 0) && (
            <Card>
              <CardContent className="text-center py-8">
                <p className="text-gray-500">Hiện tại không có tài khoản nào đang được thuê</p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-4">Hỗ trợ khách hàng</h3>
            <div className="flex justify-center space-x-6">
              <a
                href="https://zalo.me/0325882520"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors"
              >
                <span>💬</span>
                <span>Zalo</span>
              </a>
              <a
                href="https://www.facebook.com/blacknekohi/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 bg-blue-800 hover:bg-blue-900 px-4 py-2 rounded-lg transition-colors"
              >
                <span>📘</span>
                <span>Facebook</span>
              </a>
            </div>
            <p className="text-gray-400 text-sm mt-4">
              Mọi thắc mắc hay hỗ trợ vui lòng liên hệ qua các kênh trên
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <RentalModal
        isOpen={showRentalModal}
        onClose={() => setShowRentalModal(false)}
        accountId={selectedAccountId}
        pricing={pricing}
        onPackageSelected={handlePackageSelected}
        onPaymentCreated={(data) => setPaymentData(data)}
      />

      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        paymentData={paymentData}
        onSuccess={handlePaymentSuccess}
      />

      <SuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        rentalResult={rentalResult}
      />

      <AdminLoginModal
        isOpen={showAdminModal}
        onClose={() => setShowAdminModal(false)}
        onSuccess={handleAdminLogin}
      />
    </div>
  );
}
