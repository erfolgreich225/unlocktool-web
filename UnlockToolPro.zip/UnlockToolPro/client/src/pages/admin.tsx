import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  DollarSign, 
  ShoppingCart, 
  XCircle, 
  Users, 
  LogOut, 
  Plus, 
  Edit, 
  Trash, 
  Key,
  Save,
  BarChart3
} from "lucide-react";

const accountSchema = z.object({
  username: z.string().min(1, "Tên tài khoản không được trống"),
  password: z.string().min(1, "Mật khẩu không được trống"),
  status: z.enum(["available", "rented", "processing_payment"])
});

const changePasswordSchema = z.object({
  newPassword: z.string().min(1, "Mật khẩu mới không được trống")
});

export default function Admin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [selectedAccountForPassword, setSelectedAccountForPassword] = useState<number | null>(null);

  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
    refetchInterval: 30000
  });

  const { data: accounts } = useQuery({
    queryKey: ["/api/accounts"],
    refetchInterval: 10000
  });

  const { data: pricing } = useQuery({
    queryKey: ["/api/pricing"]
  });

  const addAccountMutation = useMutation({
    mutationFn: async (data: z.infer<typeof accountSchema>) => {
      const response = await apiRequest("POST", "/api/admin/accounts", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts/available"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      setShowAddAccount(false);
      form.reset();
      toast({
        title: "Thành công",
        description: "Đã thêm tài khoản mới cho khách hàng thuê"
      });
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể thêm tài khoản",
        variant: "destructive"
      });
    }
  });

  const deleteAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      await apiRequest("DELETE", `/api/admin/accounts/${accountId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts/available"] });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts/rented"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Thành công",
        description: "Đã xóa tài khoản và cập nhật thứ tự"
      });
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể xóa tài khoản",
        variant: "destructive"
      });
    }
  });

  const updatePricingMutation = useMutation({
    mutationFn: async ({ packageType, price }: { packageType: string; price: number }) => {
      const response = await apiRequest("PATCH", `/api/admin/pricing/${packageType}`, { price });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pricing"] });
      toast({
        title: "Thành công",
        description: "Đã cập nhật giá"
      });
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật giá",
        variant: "destructive"
      });
    }
  });

  const changePasswordMutation = useMutation({
    mutationFn: async ({ accountId, newPassword }: { accountId: number; newPassword: string }) => {
      const response = await apiRequest("PATCH", `/api/admin/accounts/${accountId}`, { password: newPassword });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      setShowChangePassword(false);
      toast({
        title: "Thành công",
        description: "Đã thay đổi mật khẩu thủ công"
      });
    },
    onError: () => {
      toast({
        title: "Lỗi",
        description: "Không thể thay đổi mật khẩu",
        variant: "destructive"
      });
    }
  });

  const form = useForm<z.infer<typeof accountSchema>>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      username: "",
      password: "",
      status: "available"
    }
  });

  const passwordForm = useForm<z.infer<typeof changePasswordSchema>>({
    resolver: zodResolver(changePasswordSchema),
    defaultValues: {
      newPassword: ""
    }
  });

  const handleLogout = () => {
    setLocation("/");
  };

  const handleAddAccount = (data: z.infer<typeof accountSchema>) => {
    addAccountMutation.mutate(data);
  };

  const handleDeleteAccount = (accountId: number) => {
    if (confirm("Bạn có chắc chắn muốn xóa tài khoản này?")) {
      deleteAccountMutation.mutate(accountId);
    }
  };

  const handleChangePassword = (accountId: number) => {
    setSelectedAccountForPassword(accountId);
    setShowChangePassword(true);
    passwordForm.reset();
  };

  const handlePasswordSubmit = (data: z.infer<typeof changePasswordSchema>) => {
    if (selectedAccountForPassword) {
      changePasswordMutation.mutate({
        accountId: selectedAccountForPassword,
        newPassword: data.newPassword
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "available":
        return <Badge className="bg-secondary">Sẵn sàng</Badge>;
      case "rented":
        return <Badge variant="destructive">Đang thuê</Badge>;
      case "processing_payment":
        return <Badge className="bg-warning">Đang thanh toán</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN').format(price) + '₫';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-xl font-semibold text-gray-900 flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-primary" />
              Admin Dashboard
            </h1>
            <Button
              variant="ghost"
              onClick={handleLogout}
              className="text-gray-600 hover:text-destructive"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Đăng xuất
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-secondary rounded-lg">
                  <DollarSign className="h-4 w-4 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Doanh thu hôm nay</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {formatPrice(stats?.todayRevenue || 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-primary rounded-lg">
                  <ShoppingCart className="h-4 w-4 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Đơn hàng thành công</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {stats?.successOrders || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-destructive rounded-lg">
                  <XCircle className="h-4 w-4 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Đơn hàng thất bại</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {stats?.failedOrders || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Users className="h-4 w-4 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Tài khoản hoạt động</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {stats?.activeAccounts || "0/0"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Account Management */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Quản lý tài khoản</CardTitle>
              <Dialog open={showAddAccount} onOpenChange={setShowAddAccount}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Thêm tài khoản
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Thêm tài khoản mới</DialogTitle>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleAddAccount)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tên tài khoản</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Mật khẩu</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full" disabled={addAccountMutation.isPending}>
                        {addAccountMutation.isPending ? "Đang thêm..." : "Thêm tài khoản"}
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tài khoản</TableHead>
                  <TableHead>Trạng thái</TableHead>
                  <TableHead>Thời gian còn lại</TableHead>
                  <TableHead>Thao tác</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts?.map((account: any) => (
                  <TableRow key={account.id}>
                    <TableCell>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{account.username}</div>
                        <div className="text-sm text-gray-500">{account.password}</div>
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(account.status)}</TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {account.rentEnd ? (
                        <div className="text-accent font-medium">
                          {new Date(account.rentEnd) > new Date() 
                            ? `${Math.ceil((new Date(account.rentEnd).getTime() - new Date().getTime()) / (1000 * 60 * 60))}h`
                            : "Hết hạn"
                          }
                        </div>
                      ) : "-"}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleDeleteAccount(account.id)}
                          disabled={deleteAccountMutation.isPending}
                        >
                          <Trash className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleChangePassword(account.id)}
                        >
                          <Key className="w-3 h-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Pricing Management */}
        <Card>
          <CardHeader>
            <CardTitle>Quản lý giá thuê</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pricing?.map((item: any) => (
                <div key={item.packageType} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">{item.displayName}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      defaultValue={item.price}
                      className="w-24"
                      onBlur={(e) => {
                        const newPrice = parseInt(e.target.value);
                        if (newPrice !== item.price) {
                          updatePricingMutation.mutate({
                            packageType: item.packageType,
                            price: newPrice
                          });
                        }
                      }}
                    />
                    <span className="text-sm text-gray-500">₫</span>
                  </div>
                </div>
              ))}
            </div>
            <Button className="mt-4" disabled={updatePricingMutation.isPending}>
              <Save className="w-4 h-4 mr-2" />
              {updatePricingMutation.isPending ? "Đang lưu..." : "Lưu thay đổi"}
            </Button>
          </CardContent>
        </Card>

        {/* Change Password Modal */}
        <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Thay đổi mật khẩu thủ công</DialogTitle>
            </DialogHeader>
            <Form {...passwordForm}>
              <form onSubmit={passwordForm.handleSubmit(handlePasswordSubmit)} className="space-y-4">
                <FormField
                  control={passwordForm.control}
                  name="newPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mật khẩu mới</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Nhập mật khẩu mới" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={changePasswordMutation.isPending}
                >
                  {changePasswordMutation.isPending ? "Đang cập nhật..." : "Cập nhật mật khẩu"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
