import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, ShoppingCart, CheckCircle } from "lucide-react";
import { useCountdown } from "@/hooks/use-countdown";

interface AccountCardProps {
  account: {
    id: number;
    displayName: string;
    maskedUsername: string;
    status: string;
    rentEnd?: string;
    packageType?: string;
  };
  isRented?: boolean;
  onRent?: () => void;
}

export function AccountCard({ account, isRented = false, onRent }: AccountCardProps) {
  const timeLeft = useCountdown(account.rentEnd ? new Date(account.rentEnd) : null);

  const getStatusBadge = () => {
    switch (account.status) {
      case "available":
        return (
          <Badge className="bg-secondary text-white">
            <CheckCircle className="w-3 h-3 mr-1" />
            Sẵn sàng
          </Badge>
        );
      case "rented":
        return (
          <Badge variant="destructive">
            <Clock className="w-3 h-3 mr-1" />
            Đang thuê
          </Badge>
        );
      case "processing_payment":
        return (
          <Badge className="bg-warning text-white">
            <Clock className="w-3 h-3 mr-1" />
            Đang thanh toán
          </Badge>
        );
      default:
        return <Badge variant="outline">{account.status}</Badge>;
    }
  };

  const getTimeDisplay = () => {
    if (account.status === "processing_payment") {
      // Show payment countdown (5 minutes max)
      return "05:00"; // This would be calculated based on payment start time
    }
    return timeLeft;
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h4 className="text-lg font-semibold text-gray-900">{account.displayName}</h4>
            <p className="text-gray-600">{account.maskedUsername}</p>
          </div>
          {getStatusBadge()}
        </div>

        {isRented ? (
          <div className="text-center py-3">
            <div className="text-sm text-gray-600 mb-2">
              {account.status === "processing_payment" 
                ? "Thời gian thanh toán còn lại:"
                : "Thời gian còn lại:"
              }
            </div>
            <div className={`text-2xl font-bold ${
              account.status === "processing_payment" ? "text-warning" : "text-accent"
            }`}>
              {getTimeDisplay()}
            </div>
          </div>
        ) : (
          <Button
            onClick={onRent}
            className="w-full bg-primary text-white hover:bg-blue-700 transition-colors font-medium"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Thuê ngay
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
