import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CreditCard } from "lucide-react";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface RentalModalProps {
  isOpen: boolean;
  onClose: () => void;
  accountId: number | null;
  pricing: any[];
  onPackageSelected: (packageType: string) => void;
  onPaymentCreated: (data: any) => void;
}

export function RentalModal({ 
  isOpen, 
  onClose, 
  accountId, 
  pricing, 
  onPackageSelected,
  onPaymentCreated
}: RentalModalProps) {
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const { toast } = useToast();

  const createRentalMutation = useMutation({
    mutationFn: async ({ accountId, packageType }: { accountId: number; packageType: string }) => {
      const response = await apiRequest("POST", "/api/rentals", { accountId, packageType });
      return response.json();
    },
    onSuccess: (data) => {
      onPaymentCreated(data);
      onPackageSelected(selectedPackage!);
      setSelectedPackage(null);
    },
    onError: (error: any) => {
      toast({
        title: "Lỗi",
        description: error.message || "Không thể tạo yêu cầu thuê",
        variant: "destructive"
      });
    }
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN').format(price) + '₫';
  };

  const handlePackageSelect = (packageType: string) => {
    setSelectedPackage(packageType);
  };

  const handleProceedPayment = () => {
    if (accountId && selectedPackage) {
      createRentalMutation.mutate({ accountId, packageType: selectedPackage });
    }
  };

  const getSavings = (packageType: string, price: number) => {
    // Calculate savings based on 6h price
    const hourlyRate = 16000 / 6; // Base rate from 6h package
    
    const packageHours = {
      "6h": 6,
      "12h": 12,
      "1d": 24,
      "3d": 72,
      "7d": 168
    };

    const hours = packageHours[packageType as keyof typeof packageHours] || 0;
    const fullPrice = hours * hourlyRate;
    const savings = fullPrice - price;

    return savings > 0 ? savings : 0;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Chọn gói thuê</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {pricing?.map((item) => {
            const savings = getSavings(item.packageType, item.price);
            return (
              <div
                key={item.packageType}
                className={`border rounded-lg p-4 cursor-pointer transition-all ${
                  selectedPackage === item.packageType
                    ? "border-primary bg-blue-50"
                    : "border-gray-200 hover:border-primary"
                }`}
                onClick={() => handlePackageSelect(item.packageType)}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium text-gray-900">{item.displayName}</h4>
                    <p className="text-sm text-gray-600">
                      {item.packageType === "6h" && "Gói thuê ngắn hạn"}
                      {item.packageType === "12h" && "Gói phổ biến"}
                      {item.packageType === "1d" && "24 giờ sử dụng"}
                      {item.packageType === "3d" && "72 giờ sử dụng"}
                      {item.packageType === "7d" && "Gói tiết kiệm nhất"}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-primary">{formatPrice(item.price)}</div>
                    {savings > 0 && (
                      <div className="text-xs text-secondary">Tiết kiệm {formatPrice(savings)}</div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <Button
          onClick={handleProceedPayment}
          disabled={!selectedPackage || createRentalMutation.isPending}
          className="w-full mt-6"
        >
          <CreditCard className="w-4 h-4 mr-2" />
          {createRentalMutation.isPending ? "Đang xử lý..." : "Đồng ý"}
        </Button>
      </DialogContent>
    </Dialog>
  );
}
