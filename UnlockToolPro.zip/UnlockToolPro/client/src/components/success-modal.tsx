import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, Copy } from "lucide-react";
import { useCountdown } from "@/hooks/use-countdown";
import { useToast } from "@/hooks/use-toast";

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  rentalResult: any;
}

export function SuccessModal({ isOpen, onClose, rentalResult }: SuccessModalProps) {
  const { toast } = useToast();
  
  const rentEndTime = rentalResult?.account?.rentEnd ? new Date(rentalResult.account.rentEnd) : null;
  const timeLeft = useCountdown(rentEndTime);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Đã sao chép",
      description: `${label} đã được sao chép vào clipboard`
    });
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN') + ' ' + date.toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!rentalResult?.account) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Thanh toán thành công!</h3>
          <p className="text-gray-600">Thông tin tài khoản của bạn</p>
        </div>

        {/* Account Information */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Tên tài khoản:</span>
              <div className="flex items-center space-x-2">
                <span className="font-medium">{rentalResult.account.username}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(rentalResult.account.username, "Tên tài khoản")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Mật khẩu:</span>
              <div className="flex items-center space-x-2">
                <span className="font-medium">{rentalResult.account.password}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(rentalResult.account.password, "Mật khẩu")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-600">Thời gian kết thúc:</span>
              <span className="font-medium text-accent">
                {formatDateTime(rentalResult.account.rentEnd)}
              </span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-600">Thời gian còn lại:</span>
              <span className="font-medium text-primary">{timeLeft}</span>
            </div>
          </div>
        </div>

        {/* Warning */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <div className="flex items-start">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mr-2 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-yellow-800">
              <p className="font-medium mb-1">Lưu ý quan trọng:</p>
              <p>Sau khi hết thời gian thuê, mật khẩu sẽ được tự động thay đổi. Vui lòng sao lưu dữ liệu quan trọng trước khi hết hạn.</p>
            </div>
          </div>
        </div>

        <Button onClick={onClose} className="w-full">
          Đóng
        </Button>
      </DialogContent>
    </Dialog>
  );
}
