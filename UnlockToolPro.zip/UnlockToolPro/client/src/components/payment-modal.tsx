import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { QrCode } from "lucide-react";
import { apiRequest } from "@/lib/api";
import { useCountdown } from "@/hooks/use-countdown";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  paymentData: any;
  onSuccess: (result: any) => void;
}

export function PaymentModal({ isOpen, onClose, paymentData, onSuccess }: PaymentModalProps) {
  const [checkInterval, setCheckInterval] = useState<NodeJS.Timeout | null>(null);
  
  // 5 minute countdown from now
  const paymentDeadline = new Date(Date.now() + 5 * 60 * 1000);
  const timeLeft = useCountdown(paymentDeadline);

  const checkPaymentMutation = useMutation({
    mutationFn: async (orderCode: string) => {
      const response = await apiRequest("GET", `/api/payments/${orderCode}`);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.status === "completed") {
        if (checkInterval) {
          clearInterval(checkInterval);
          setCheckInterval(null);
        }
        onSuccess(data);
      }
    }
  });

  useEffect(() => {
    if (isOpen && paymentData?.orderCode) {
      // Check payment status every 3 seconds
      const interval = setInterval(() => {
        checkPaymentMutation.mutate(paymentData.orderCode.toString());
      }, 3000);
      
      setCheckInterval(interval);

      // Cleanup on unmount or close
      return () => {
        if (interval) {
          clearInterval(interval);
        }
      };
    }
  }, [isOpen, paymentData?.orderCode]);

  useEffect(() => {
    // Stop checking if time runs out
    if (timeLeft === "00:00") {
      if (checkInterval) {
        clearInterval(checkInterval);
        setCheckInterval(null);
      }
      onClose();
    }
  }, [timeLeft]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN').format(price) + '₫';
  };

  if (!paymentData) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Thanh toán</DialogTitle>
        </DialogHeader>

        <div className="text-center">
          <div className="text-sm text-gray-600 mb-4">Quét mã QR để thanh toán</div>
          
          {/* QR Code Display */}
          <div className="bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg p-8 mb-4">
            {paymentData.qrCode ? (
              <img 
                src={paymentData.qrCode} 
                alt="QR Code thanh toán"
                className="w-48 h-48 mx-auto"
              />
            ) : (
              <div className="w-48 h-48 mx-auto bg-white border border-gray-200 rounded-lg flex items-center justify-center">
                <QrCode className="w-16 h-16 text-gray-400" />
              </div>
            )}
            <p className="text-xs text-gray-500 mt-2">QR Code từ PayOS</p>
          </div>

          {/* Payment Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
            <div className="text-sm text-gray-700 space-y-2">
              <div className="flex justify-between">
                <span>Gói thuê:</span>
                <span className="font-medium">{paymentData.packageName}</span>
              </div>
              <div className="flex justify-between">
                <span>Số tiền:</span>
                <span className="font-medium text-primary">{formatPrice(paymentData.amount)}</span>
              </div>
            </div>
          </div>

          {/* Countdown */}
          <div className="text-center">
            <div className="text-sm text-gray-600 mb-2">Thời gian còn lại để thanh toán:</div>
            <div className="text-2xl font-bold text-accent">{timeLeft}</div>
          </div>

          {/* Payment URL as fallback */}
          {paymentData.paymentUrl && (
            <div className="mt-4">
              <a
                href={paymentData.paymentUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary underline text-sm"
              >
                Mở liên kết thanh toán trong tab mới
              </a>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
