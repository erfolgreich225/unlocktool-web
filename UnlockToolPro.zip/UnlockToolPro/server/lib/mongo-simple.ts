import { MongoClient, Db, Collection } from 'mongodb';
import { Account, Rental, Admin, Pricing, Stats, InsertAccount, InsertRental, InsertAdmin } from '../../shared/schema';
import { IStorage } from '../storage';

export class SimpleMongoStorage implements IStorage {
  private client: MongoClient;
  private db: Db;
  private connected: boolean = false;

  constructor() {
    const uri = process.env.MONGODB_URI;
    if (!uri) {
      throw new Error('MONGODB_URI không được cấu hình');
    }
    
    this.client = new MongoClient(uri);
    this.db = this.client.db('unlocktool-rental');
  }

  async connect(): Promise<void> {
    if (!this.connected) {
      await this.client.connect();
      this.connected = true;
      console.log('✅ Đã kết nối MongoDB Atlas thành công');
      await this.initializeDefaultData();
    }
  }

  async disconnect(): Promise<void> {
    if (this.connected) {
      await this.client.close();
      this.connected = false;
      console.log('🔌 Đã ngắt kết nối MongoDB Atlas');
    }
  }

  private async initializeDefaultData(): Promise<void> {
    const accounts = this.db.collection('accounts');
    const admins = this.db.collection('admins');
    const pricing = this.db.collection('pricing');
    const stats = this.db.collection('stats');

    // Khởi tạo admin mặc định
    const adminExists = await admins.findOne({ username: 'admin' });
    if (!adminExists) {
      await admins.insertOne({
        id: 1,
        username: 'admin',
        password: 'admin123',
        isActive: true,
        createdAt: new Date()
      });
      console.log('👤 Đã tạo admin mặc định');
    }

    // Khởi tạo bảng giá
    const pricingExists = await pricing.findOne({});
    if (!pricingExists) {
      const defaultPricing = [
        { id: 1, packageType: '6h', price: 16000, duration: 6, displayName: '6 giờ', updatedAt: null },
        { id: 2, packageType: '12h', price: 25000, duration: 12, displayName: '12 giờ', updatedAt: null },
        { id: 3, packageType: '1d', price: 35000, duration: 24, displayName: '1 ngày', updatedAt: null },
        { id: 4, packageType: '3d', price: 80000, duration: 72, displayName: '3 ngày', updatedAt: null },
        { id: 5, packageType: '7d', price: 150000, duration: 168, displayName: '7 ngày', updatedAt: null }
      ];
      await pricing.insertMany(defaultPricing);
      console.log('💰 Đã tạo bảng giá mặc định');
    }

    // Khởi tạo tài khoản mẫu
    const accountExists = await accounts.findOne({});
    if (!accountExists) {
      const sampleAccounts = [
        {
          id: 1,
          username: 'unlockuser001',
          password: 'thuetool.online001',
          status: 'available',
          rentedBy: null,
          rentStart: null,
          rentEnd: null,
          packageType: null,
          createdAt: new Date(),
          updatedAt: null
        },
        {
          id: 2,
          username: 'unlockuser002', 
          password: 'thuetool.online002',
          status: 'available',
          rentedBy: null,
          rentStart: null,
          rentEnd: null,
          packageType: null,
          createdAt: new Date(),
          updatedAt: null
        }
      ];
      await accounts.insertMany(sampleAccounts);
      console.log('🏦 Đã tạo tài khoản mẫu');
    }

    // Khởi tạo thống kê hôm nay
    const today = new Date().toISOString().split('T')[0];
    const statsExists = await stats.findOne({ date: today });
    if (!statsExists) {
      await stats.insertOne({
        id: 1,
        date: today,
        totalRevenue: 0,
        successfulOrders: 0,
        failedOrders: 0,
        updatedAt: null
      });
      console.log('📊 Đã khởi tạo thống kê hôm nay');
    }
  }

  // Account methods
  async getAccounts(): Promise<Account[]> {
    await this.connect();
    const accounts = this.db.collection('accounts');
    const result = await accounts.find({}).sort({ id: 1 }).toArray();
    return result.map(this.convertToAccount);
  }

  async getAccount(id: number): Promise<Account | undefined> {
    await this.connect();
    const accounts = this.db.collection('accounts');
    const result = await accounts.findOne({ id });
    return result ? this.convertToAccount(result) : undefined;
  }

  async getAvailableAccounts(): Promise<Account[]> {
    await this.connect();
    const accounts = this.db.collection('accounts');
    const result = await accounts.find({ status: 'available' }).sort({ id: 1 }).toArray();
    return result.map(this.convertToAccount);
  }

  async getRentedAccounts(): Promise<Account[]> {
    await this.connect();
    const accounts = this.db.collection('accounts');
    const result = await accounts.find({ status: 'rented' }).sort({ id: 1 }).toArray();
    return result.map(this.convertToAccount);
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    await this.connect();
    const accounts = this.db.collection('accounts');
    
    // Tìm ID tiếp theo
    const lastAccount = await accounts.findOne({}, { sort: { id: -1 } });
    const nextId = lastAccount ? lastAccount.id + 1 : 1;
    
    const newAccount = {
      id: nextId,
      username: insertAccount.username,
      password: insertAccount.password,
      status: insertAccount.status || 'available',
      rentedBy: null,
      rentStart: null,
      rentEnd: null,
      packageType: null,
      createdAt: new Date(),
      updatedAt: null
    };

    await accounts.insertOne(newAccount);
    return this.convertToAccount(newAccount);
  }

  async updateAccount(id: number, updates: Partial<Account>): Promise<Account | undefined> {
    await this.connect();
    const accounts = this.db.collection('accounts');
    
    const result = await accounts.findOneAndUpdate(
      { id },
      { $set: { ...updates, updatedAt: new Date() } },
      { returnDocument: 'after' }
    );
    
    return result ? this.convertToAccount(result) : undefined;
  }

  async deleteAccount(id: number): Promise<boolean> {
    await this.connect();
    const accounts = this.db.collection('accounts');
    
    const deleteResult = await accounts.deleteOne({ id });
    
    if (deleteResult.deletedCount > 0) {
      // Cập nhật lại ID các tài khoản sau
      const accountsAfter = await accounts.find({ id: { $gt: id } }).sort({ id: 1 }).toArray();
      
      for (let i = 0; i < accountsAfter.length; i++) {
        const account = accountsAfter[i];
        const newId = id + i;
        await accounts.updateOne(
          { _id: account._id },
          { $set: { id: newId, updatedAt: new Date() } }
        );
      }
      
      return true;
    }
    
    return false;
  }

  // Helper method to convert MongoDB document to Account type
  private convertToAccount(doc: any): Account {
    return {
      id: doc.id,
      username: doc.username,
      password: doc.password,
      status: doc.status,
      rentedBy: doc.rentedBy,
      rentStart: doc.rentStart,
      rentEnd: doc.rentEnd,
      packageType: doc.packageType,
      createdAt: doc.createdAt,
      updatedAt: doc.updatedAt
    };
  }

  // Rental methods
  async getRentals(): Promise<Rental[]> {
    await this.connect();
    const rentals = this.db.collection('rentals');
    const result = await rentals.find({}).sort({ id: -1 }).toArray();
    return result.map(this.convertToRental);
  }

  async getRental(id: number): Promise<Rental | undefined> {
    await this.connect();
    const rentals = this.db.collection('rentals');
    const result = await rentals.findOne({ id });
    return result ? this.convertToRental(result) : undefined;
  }

  async getRentalByOrderCode(orderCode: string): Promise<Rental | undefined> {
    await this.connect();
    const rentals = this.db.collection('rentals');
    const result = await rentals.findOne({ paymentOrderCode: orderCode });
    return result ? this.convertToRental(result) : undefined;
  }

  async createRental(insertRental: InsertRental): Promise<Rental> {
    await this.connect();
    const rentals = this.db.collection('rentals');
    
    const lastRental = await rentals.findOne({}, { sort: { id: -1 } });
    const nextId = lastRental ? lastRental.id + 1 : 1;
    
    const newRental = {
      id: nextId,
      packageType: insertRental.packageType,
      accountId: insertRental.accountId,
      price: insertRental.price,
      rentStart: insertRental.rentStart || null,
      rentEnd: insertRental.rentEnd || null,
      paymentStatus: insertRental.paymentStatus || 'pending',
      paymentOrderCode: insertRental.paymentOrderCode || null,
      paymentUrl: insertRental.paymentUrl || null,
      customerInfo: insertRental.customerInfo || null,
      createdAt: new Date(),
      updatedAt: null
    };

    await rentals.insertOne(newRental);
    return this.convertToRental(newRental);
  }

  async updateRental(id: number, updates: Partial<Rental>): Promise<Rental | undefined> {
    await this.connect();
    const rentals = this.db.collection('rentals');
    
    const result = await rentals.findOneAndUpdate(
      { id },
      { $set: updates },
      { returnDocument: 'after' }
    );
    
    return result ? this.convertToRental(result) : undefined;
  }

  private convertToRental(doc: any): Rental {
    return {
      id: doc.id,
      packageType: doc.packageType,
      accountId: doc.accountId,
      price: doc.price,
      rentStart: doc.rentStart,
      rentEnd: doc.rentEnd,
      paymentStatus: doc.paymentStatus,
      paymentOrderCode: doc.paymentOrderCode,
      paymentUrl: doc.paymentUrl,
      customerInfo: doc.customerInfo
    };
  }

  // Admin methods
  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    await this.connect();
    const admins = this.db.collection('admins');
    const result = await admins.findOne({ username });
    return result ? this.convertToAdmin(result) : undefined;
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    await this.connect();
    const admins = this.db.collection('admins');
    
    const lastAdmin = await admins.findOne({}, { sort: { id: -1 } });
    const nextId = lastAdmin ? lastAdmin.id + 1 : 1;
    
    const newAdmin = {
      id: nextId,
      username: insertAdmin.username,
      password: insertAdmin.password,
      isActive: true,
      createdAt: new Date()
    };

    await admins.insertOne(newAdmin);
    return this.convertToAdmin(newAdmin);
  }

  private convertToAdmin(doc: any): Admin {
    return {
      id: doc.id,
      username: doc.username,
      password: doc.password,
      isActive: doc.isActive,
      createdAt: doc.createdAt
    };
  }

  // Pricing methods
  async getPricing(): Promise<Pricing[]> {
    await this.connect();
    const pricing = this.db.collection('pricing');
    const result = await pricing.find({}).toArray();
    return result.map(this.convertToPricing);
  }

  async getPricingByPackage(packageType: string): Promise<Pricing | undefined> {
    await this.connect();
    const pricing = this.db.collection('pricing');
    const result = await pricing.findOne({ packageType });
    return result ? this.convertToPricing(result) : undefined;
  }

  async updatePricing(packageType: string, updates: Partial<Pricing>): Promise<Pricing | undefined> {
    await this.connect();
    const pricing = this.db.collection('pricing');
    
    const result = await pricing.findOneAndUpdate(
      { packageType },
      { $set: { ...updates, updatedAt: new Date() } },
      { returnDocument: 'after' }
    );
    
    return result ? this.convertToPricing(result) : undefined;
  }

  private convertToPricing(doc: any): Pricing {
    return {
      id: doc.id,
      packageType: doc.packageType,
      price: doc.price,
      duration: doc.duration,
      displayName: doc.displayName,
      updatedAt: doc.updatedAt
    };
  }

  // Stats methods
  async getStatsForDate(date: string): Promise<Stats | undefined> {
    await this.connect();
    const stats = this.db.collection('stats');
    const result = await stats.findOne({ date });
    return result ? this.convertToStats(result) : undefined;
  }

  async updateStats(date: string, updates: Partial<Stats>): Promise<Stats> {
    await this.connect();
    const stats = this.db.collection('stats');
    
    const existing = await stats.findOne({ date });
    if (existing) {
      const result = await stats.findOneAndUpdate(
        { date },
        { $set: { ...updates, updatedAt: new Date() } },
        { returnDocument: 'after' }
      );
      return this.convertToStats(result!);
    } else {
      const newStats = {
        id: Math.floor(Math.random() * 1000000),
        date,
        totalRevenue: updates.totalRevenue || 0,
        successfulOrders: updates.successfulOrders || 0,
        failedOrders: updates.failedOrders || 0,
        updatedAt: new Date()
      };
      
      await stats.insertOne(newStats);
      return this.convertToStats(newStats);
    }
  }

  private convertToStats(doc: any): Stats {
    return {
      id: doc.id,
      date: doc.date,
      totalRevenue: doc.totalRevenue,
      successfulOrders: doc.successfulOrders,
      failedOrders: doc.failedOrders,
      updatedAt: doc.updatedAt
    };
  }
}