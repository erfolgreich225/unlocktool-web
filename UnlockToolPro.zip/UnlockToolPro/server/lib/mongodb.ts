import { MongoClient, Db, Collection } from 'mongodb';
import { IStorage } from '../storage';

// Simplified MongoDB types
interface MongoAccount {
  _id?: any;
  id: number;
  username: string;
  password: string;
  displayName: string;
  maskedUsername: string;
  status: string;
  rentedBy?: string;
  rentStart?: Date;
  rentEnd?: Date;
  packageType?: string;
  createdAt: Date;
}

interface MongoRental {
  _id?: any;
  id: number;
  accountId: number;
  packageType: string;
  orderCode: string;
  amount: number;
  status: string;
  paymentStatus: string;
  rentStart?: Date;
  rentEnd?: Date;
  createdAt: Date;
}

interface MongoAdmin {
  _id?: any;
  id: number;
  username: string;
  password: string;
  createdAt: Date;
}

interface MongoPricing {
  _id?: any;
  id: number;
  packageType: string;
  price: number;
  duration: number;
  displayName: string;
  createdAt: Date;
}

interface MongoStats {
  _id?: any;
  id: number;
  date: string;
  todayRevenue: number;
  successOrders: number;
  failedOrders: number;
  activeAccounts: number;
  createdAt: Date;
}

export class MongoStorage implements IStorage {
  private client: MongoClient;
  private db: Db;
  private accounts: Collection<MongoAccount>;
  private rentals: Collection<MongoRental>;
  private admins: Collection<MongoAdmin>;
  private pricing: Collection<MongoPricing>;
  private stats: Collection<MongoStats>;
  private isConnected: boolean = false;

  constructor() {
    const uri = process.env.MONGODB_URI;
    if (!uri) {
      throw new Error('MONGODB_URI environment variable is not set');
    }
    
    this.client = new MongoClient(uri);
    this.db = this.client.db('unlocktool');
    this.accounts = this.db.collection<Account>('accounts');
    this.rentals = this.db.collection<Rental>('rentals');
    this.admins = this.db.collection<Admin>('admins');
    this.pricing = this.db.collection<Pricing>('pricing');
    this.stats = this.db.collection<Stats>('stats');
  }

  async connect(): Promise<void> {
    if (!this.isConnected) {
      await this.client.connect();
      this.isConnected = true;
      console.log('Connected to MongoDB Atlas');
      
      // Khởi tạo dữ liệu mặc định nếu chưa có
      await this.initializeData();
    }
  }

  async disconnect(): Promise<void> {
    if (this.isConnected) {
      await this.client.close();
      this.isConnected = false;
      console.log('Disconnected from MongoDB Atlas');
    }
  }

  private async initializeData(): Promise<void> {
    // Khởi tạo admin mặc định
    const adminExists = await this.admins.findOne({ username: 'admin' });
    if (!adminExists) {
      await this.admins.insertOne({
        id: 1,
        username: 'admin',
        password: 'admin123',
        createdAt: new Date(),
        isActive: true
      });
    }

    // Khởi tạo bảng giá mặc định
    const pricingExists = await this.pricing.findOne({});
    if (!pricingExists) {
      const defaultPricing = [
        { id: Math.floor(Math.random() * 1000000), packageType: '6h', price: 16000, createdAt: new Date() },
        { id: Math.floor(Math.random() * 1000000), packageType: '12h', price: 25000, createdAt: new Date() },
        { id: Math.floor(Math.random() * 1000000), packageType: '1d', price: 35000, createdAt: new Date() },
        { id: Math.floor(Math.random() * 1000000), packageType: '3d', price: 80000, createdAt: new Date() },
        { id: Math.floor(Math.random() * 1000000), packageType: '7d', price: 150000, createdAt: new Date() }
      ];
      await this.pricing.insertMany(defaultPricing);
    }

    // Khởi tạo tài khoản mẫu
    const accountExists = await this.accounts.findOne({});
    if (!accountExists) {
      const sampleAccounts = [
        {
          id: 2,
          username: 'unlockuser002',
          password: 'samplepass002',
          displayName: 'No.02',
          maskedUsername: 'unlock***002',
          status: 'available',
          createdAt: new Date()
        },
        {
          id: 3,
          username: 'unlockuser003',
          password: 'samplepass003',
          displayName: 'No.03',
          maskedUsername: 'unlock***003',
          status: 'available',
          createdAt: new Date()
        }
      ];
      await this.accounts.insertMany(sampleAccounts);
    }

    // Khởi tạo thống kê ngày hôm nay
    const today = new Date().toISOString().split('T')[0];
    const statsExists = await this.stats.findOne({ date: today });
    if (!statsExists) {
      await this.stats.insertOne({
        id: Math.floor(Math.random() * 1000000),
        date: today,
        todayRevenue: 0,
        successOrders: 0,
        failedOrders: 0,
        activeAccounts: 2,
        createdAt: new Date()
      });
    }
  }

  // Account methods
  async getAccounts(): Promise<Account[]> {
    await this.connect();
    return await this.accounts.find({}).sort({ id: 1 }).toArray();
  }

  async getAccount(id: number): Promise<Account | undefined> {
    await this.connect();
    const account = await this.accounts.findOne({ id });
    return account || undefined;
  }

  async getAvailableAccounts(): Promise<Account[]> {
    await this.connect();
    return await this.accounts.find({ status: 'available' }).sort({ id: 1 }).toArray();
  }

  async getRentedAccounts(): Promise<Account[]> {
    await this.connect();
    return await this.accounts.find({ status: 'rented' }).sort({ id: 1 }).toArray();
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    await this.connect();
    
    // Tìm ID tiếp theo
    const lastAccount = await this.accounts.findOne({}, { sort: { id: -1 } });
    const nextId = lastAccount ? lastAccount.id + 1 : 1;
    
    const account: Account = {
      id: nextId,
      username: insertAccount.username,
      password: insertAccount.password,
      displayName: `No.${nextId.toString().padStart(2, '0')}`,
      maskedUsername: insertAccount.username.replace(/(.{6}).*(.{3})/, '$1***$2'),
      status: insertAccount.status || 'available',
      createdAt: new Date()
    };

    await this.accounts.insertOne(account);
    return account;
  }

  async updateAccount(id: number, updates: Partial<Account>): Promise<Account | undefined> {
    await this.connect();
    const result = await this.accounts.findOneAndUpdate(
      { id },
      { $set: { ...updates, updatedAt: new Date() } },
      { returnDocument: 'after' }
    );
    return result || undefined;
  }

  async deleteAccount(id: number): Promise<boolean> {
    await this.connect();
    
    // Xóa tài khoản
    const deleteResult = await this.accounts.deleteOne({ id });
    
    if (deleteResult.deletedCount > 0) {
      // Cập nhật lại ID của các tài khoản sau để đánh số lại
      const accountsAfter = await this.accounts.find({ id: { $gt: id } }).sort({ id: 1 }).toArray();
      
      for (let i = 0; i < accountsAfter.length; i++) {
        const account = accountsAfter[i];
        const newId = id + i;
        await this.accounts.updateOne(
          { _id: account._id },
          { 
            $set: { 
              id: newId,
              displayName: `No.${newId.toString().padStart(2, '0')}`,
              updatedAt: new Date()
            }
          }
        );
      }
      
      return true;
    }
    
    return false;
  }

  // Rental methods
  async getRentals(): Promise<Rental[]> {
    await this.connect();
    return await this.rentals.find({}).sort({ id: -1 }).toArray();
  }

  async getRental(id: number): Promise<Rental | undefined> {
    await this.connect();
    const rental = await this.rentals.findOne({ id });
    return rental || undefined;
  }

  async getRentalByOrderCode(orderCode: string): Promise<Rental | undefined> {
    await this.connect();
    const rental = await this.rentals.findOne({ orderCode });
    return rental || undefined;
  }

  async createRental(insertRental: InsertRental): Promise<Rental> {
    await this.connect();
    
    const lastRental = await this.rentals.findOne({}, { sort: { id: -1 } });
    const nextId = lastRental ? lastRental.id + 1 : 1;
    
    const rental: Rental = {
      id: nextId,
      accountId: insertRental.accountId,
      packageType: insertRental.packageType,
      orderCode: insertRental.orderCode,
      amount: insertRental.amount,
      status: insertRental.status,
      paymentStatus: insertRental.paymentStatus || 'pending',
      rentStart: insertRental.rentStart,
      rentEnd: insertRental.rentEnd,
      createdAt: new Date()
    };

    await this.rentals.insertOne(rental);
    return rental;
  }

  async updateRental(id: number, updates: Partial<Rental>): Promise<Rental | undefined> {
    await this.connect();
    const result = await this.rentals.findOneAndUpdate(
      { id },
      { $set: { ...updates, updatedAt: new Date() } },
      { returnDocument: 'after' }
    );
    return result || undefined;
  }

  // Admin methods
  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    await this.connect();
    const admin = await this.admins.findOne({ username });
    return admin || undefined;
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    await this.connect();
    
    const lastAdmin = await this.admins.findOne({}, { sort: { id: -1 } });
    const nextId = lastAdmin ? lastAdmin.id + 1 : 1;
    
    const admin: Admin = {
      id: nextId,
      username: insertAdmin.username,
      password: insertAdmin.password,
      createdAt: new Date()
    };

    await this.admins.insertOne(admin);
    return admin;
  }

  // Pricing methods
  async getPricing(): Promise<Pricing[]> {
    await this.connect();
    return await this.pricing.find({}).toArray();
  }

  async getPricingByPackage(packageType: string): Promise<Pricing | undefined> {
    await this.connect();
    const pricing = await this.pricing.findOne({ packageType });
    return pricing || undefined;
  }

  async updatePricing(packageType: string, updates: Partial<Pricing>): Promise<Pricing | undefined> {
    await this.connect();
    const result = await this.pricing.findOneAndUpdate(
      { packageType },
      { $set: { ...updates, updatedAt: new Date() } },
      { returnDocument: 'after' }
    );
    return result || undefined;
  }

  // Stats methods
  async getStatsForDate(date: string): Promise<Stats | undefined> {
    await this.connect();
    const stats = await this.stats.findOne({ date });
    return stats || undefined;
  }

  async updateStats(date: string, updates: Partial<Stats>): Promise<Stats> {
    await this.connect();
    
    const existing = await this.stats.findOne({ date });
    if (existing) {
      const result = await this.stats.findOneAndUpdate(
        { date },
        { $set: { ...updates, updatedAt: new Date() } },
        { returnDocument: 'after' }
      );
      return result!;
    } else {
      const newStats: Stats = {
        id: Math.floor(Math.random() * 1000000),
        date,
        todayRevenue: updates.todayRevenue || 0,
        successOrders: updates.successOrders || 0,
        failedOrders: updates.failedOrders || 0,
        activeAccounts: updates.activeAccounts || 0,
        createdAt: new Date()
      };
      
      await this.stats.insertOne(newStats);
      return newStats;
    }
  }
}