import { storage } from "../storage";
import { changePassword, generateNewPassword } from "./puppeteer";

class RentalScheduler {
  private intervalId: NodeJS.Timeout | null = null;

  start() {
    // Check every minute for expired rentals
    this.intervalId = setInterval(async () => {
      await this.checkExpiredRentals();
    }, 60000);

    console.log('Rental scheduler started');
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    console.log('Rental scheduler stopped');
  }

  private async checkExpiredRentals() {
    try {
      const rentedAccounts = await storage.getRentedAccounts();
      const now = new Date();

      for (const account of rentedAccounts) {
        if (account.status === "rented" && account.rentEnd && new Date(account.rentEnd) <= now) {
          console.log(`Account ${account.username} rental expired, changing password...`);
          
          // Change password using puppeteer
          const result = await changePassword({
            id: account.id,
            username: account.username,
            password: account.password
          });

          if (result.success && result.newPassword) {
            // Update account with new password
            await storage.updateAccount(account.id, {
              status: "available",
              password: result.newPassword,
              rentedBy: null,
              rentStart: null,
              rentEnd: null,
              packageType: null
            });

            console.log(`Account ${account.username} is now available with new password: ${result.newPassword}`);
          } else {
            console.error(`Failed to change password for account ${account.username}`);
          }
        }

        // Check for payment timeouts (5 minutes)
        if (account.status === "processing_payment" && account.rentStart) {
          const paymentStartTime = new Date(account.rentStart);
          const timeoutTime = new Date(paymentStartTime.getTime() + 5 * 60 * 1000); // 5 minutes

          if (now >= timeoutTime) {
            console.log(`Payment timeout for account ${account.username}, reverting to available`);
            
            await storage.updateAccount(account.id, {
              status: "available",
              rentedBy: null,
              rentStart: null,
              rentEnd: null,
              packageType: null
            });

            // Update failed order count
            const today = now.toISOString().split('T')[0];
            const todayStats = await storage.getStatsForDate(today);
            if (todayStats) {
              await storage.updateStats(today, {
                failedOrders: (todayStats.failedOrders || 0) + 1
              });
            }
          }
        }
      }
    } catch (error) {
      console.error('Error checking expired rentals:', error);
    }
  }
}

const scheduler = new RentalScheduler();

export { scheduler };
