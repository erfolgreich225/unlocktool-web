interface PayOSConfig {
  clientId: string;
  apiKey: string;
  checksumKey: string;
}

interface ItemData {
  name: string;
  quantity: number;
  price: number;
}

interface PaymentData {
  orderCode: number;
  amount: number;
  description: string;
  returnUrl: string;
  cancelUrl: string;
  items: ItemData[];
}

interface PaymentResponse {
  error: number;
  message: string;
  data?: {
    bin: string;
    accountNumber: string;
    accountName: string;
    amount: number;
    description: string;
    orderCode: number;
    currency: string;
    paymentLinkId: string;
    status: string;
    checkoutUrl: string;
    qrCode: string;
  };
}

class PayOS {
  private config: PayOSConfig;

  constructor(clientId: string, apiKey: string, checksumKey: string) {
    this.config = {
      clientId,
      apiKey,
      checksumKey
    };
  }

  async createPaymentLink(paymentData: PaymentData): Promise<PaymentResponse> {
    try {
      const response = await fetch('https://api-merchant.payos.vn/v2/payment-requests', {
        method: 'POST',
        headers: {
          'x-client-id': this.config.clientId,
          'x-api-key': this.config.apiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(paymentData)
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error('PayOS Error:', error);
      throw new Error('Payment processing failed');
    }
  }

  async getPaymentLinkInformation(orderCode: number): Promise<any> {
    try {
      const response = await fetch(`https://api-merchant.payos.vn/v2/payment-requests/${orderCode}`, {
        headers: {
          'x-client-id': this.config.clientId,
          'x-api-key': this.config.apiKey
        }
      });

      return await response.json();
    } catch (error) {
      console.error('PayOS Error:', error);
      throw new Error('Failed to get payment information');
    }
  }

  async cancelPaymentLink(orderCode: number, cancellationReason?: string): Promise<any> {
    try {
      const response = await fetch(`https://api-merchant.payos.vn/v2/payment-requests/${orderCode}/cancel`, {
        method: 'POST',
        headers: {
          'x-client-id': this.config.clientId,
          'x-api-key': this.config.apiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          cancellationReason: cancellationReason || 'Cancelled by system'
        })
      });

      return await response.json();
    } catch (error) {
      console.error('PayOS Error:', error);
      throw new Error('Failed to cancel payment');
    }
  }

  verifyPaymentWebhookData(webhookBody: any): any {
    // Implement webhook verification logic according to PayOS documentation
    // This would typically involve verifying the signature
    return webhookBody;
  }
}

const payOS = new PayOS(
  process.env.PAYOS_CLIENT_ID || "2639c5df-ffba-4838-8652-eb1a4e0ccb3e",
  process.env.PAYOS_API_KEY || "0143cc93-64bb-453c-a017-01524ef7f5eb",
  process.env.PAYOS_CHECKSUM_KEY || "3ab937d4ffb589b3a9a745f2280bd900e4808f5c2d6b2ee45958e508a8e2344e"
);

export { PayOS, payOS };
export type { PaymentData, PaymentResponse };
