import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { payOS } from "./lib/payos";
import { scheduler } from "./lib/scheduler";
import { changePassword } from "./lib/puppeteer";
import { loginSchema, rentalRequestSchema, insertAccountSchema, insertPricingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Start the rental scheduler
  scheduler.start();

  // Get all accounts with status
  app.get("/api/accounts", async (req, res) => {
    try {
      const accounts = await storage.getAccounts();
      
      // Mask usernames for privacy
      const maskedAccounts = accounts.map(account => ({
        ...account,
        maskedUsername: account.username.substring(0, 2) + "*".repeat(Math.max(0, account.username.length - 2)),
        password: account.status === "rented" ? account.password : undefined // Only show password for rented accounts
      }));

      res.json(maskedAccounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch accounts" });
    }
  });

  // Get available accounts
  app.get("/api/accounts/available", async (req, res) => {
    try {
      const accounts = await storage.getAvailableAccounts();
      
      const maskedAccounts = accounts.map(account => ({
        ...account,
        maskedUsername: account.username.substring(0, 2) + "*".repeat(Math.max(0, account.username.length - 2))
      }));

      res.json(maskedAccounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch available accounts" });
    }
  });

  // Get rented accounts
  app.get("/api/accounts/rented", async (req, res) => {
    try {
      const accounts = await storage.getRentedAccounts();
      
      const maskedAccounts = accounts.map(account => ({
        ...account,
        maskedUsername: account.username.substring(0, 2) + "*".repeat(Math.max(0, account.username.length - 2))
      }));

      res.json(maskedAccounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rented accounts" });
    }
  });

  // Get pricing
  app.get("/api/pricing", async (req, res) => {
    try {
      const pricing = await storage.getPricing();
      res.json(pricing);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pricing" });
    }
  });

  // Create rental request
  app.post("/api/rentals", async (req, res) => {
    try {
      const { accountId, packageType } = rentalRequestSchema.parse(req.body);

      // Check if account is available
      const account = await storage.getAccount(accountId);
      if (!account || account.status !== "available") {
        return res.status(400).json({ message: "Tài khoản không khả dụng" });
      }

      // Get pricing for package
      const pricing = await storage.getPricingByPackage(packageType);
      if (!pricing) {
        return res.status(400).json({ message: "Gói thuê không tồn tại" });
      }

      // Update account status to processing payment
      await storage.updateAccount(accountId, {
        status: "processing_payment",
        rentStart: new Date(),
        packageType
      });

      // Generate unique order code
      const orderCode = Date.now();

      // Create payment link with PayOS
      const maskedUsername = account.username.substring(0, 2) + "*".repeat(Math.max(0, account.username.length - 2));
      const paymentData = {
        orderCode,
        amount: pricing.price,
        description: `Thuê tài khoản ${maskedUsername} - ${pricing.displayName}`,
        returnUrl: `${process.env.BASE_URL || 'http://localhost:5000'}/payment/success`,
        cancelUrl: `${process.env.BASE_URL || 'http://localhost:5000'}/payment/cancel`,
        items: [{
          name: `Thuê tài khoản UnlockTool - ${pricing.displayName}`,
          quantity: 1,
          price: pricing.price
        }]
      };

      const paymentResponse = await payOS.createPaymentLink(paymentData);

      if (paymentResponse.error === 0 && paymentResponse.data) {
        // Create rental record
        const rental = await storage.createRental({
          accountId,
          packageType,
          price: pricing.price,
          paymentStatus: "pending",
          paymentOrderCode: orderCode.toString(),
          paymentUrl: paymentResponse.data.checkoutUrl,
          rentStart: null,
          rentEnd: null,
          customerInfo: null
        });

        res.json({
          rentalId: rental.id,
          orderCode,
          paymentUrl: paymentResponse.data.checkoutUrl,
          qrCode: paymentResponse.data.qrCode,
          amount: pricing.price,
          packageName: pricing.displayName
        });
      } else {
        // Revert account status if payment creation failed
        await storage.updateAccount(accountId, {
          status: "available",
          rentStart: null,
          packageType: null
        });

        res.status(500).json({ message: "Không thể tạo liên kết thanh toán" });
      }
    } catch (error) {
      console.error("Rental creation error:", error);
      res.status(500).json({ message: "Lỗi tạo yêu cầu thuê" });
    }
  });

  // Check payment status
  app.get("/api/payments/:orderCode", async (req, res) => {
    try {
      const { orderCode } = req.params;

      // Get payment info from PayOS
      const paymentInfo = await payOS.getPaymentLinkInformation(parseInt(orderCode));
      
      // Get rental record
      const rental = await storage.getRentalByOrderCode(orderCode);
      if (!rental) {
        return res.status(404).json({ message: "Không tìm thấy đơn hàng" });
      }

      // Check if payment is successful
      if (paymentInfo.data?.status === "PAID") {
        // Payment successful, activate rental
        const account = await storage.getAccount(rental.accountId);
        if (account) {
          const pricing = await storage.getPricingByPackage(rental.packageType);
          if (pricing) {
            const rentStart = new Date();
            const rentEnd = new Date(rentStart.getTime() + pricing.duration * 60 * 60 * 1000);

            // Update account to rented status
            await storage.updateAccount(rental.accountId, {
              status: "rented",
              rentStart,
              rentEnd,
              rentedBy: "customer" // In real app, this would be customer ID
            });

            // Update rental record
            await storage.updateRental(rental.id, {
              paymentStatus: "completed",
              rentStart,
              rentEnd
            });

            // Update stats
            const today = new Date().toISOString().split('T')[0];
            const todayStats = await storage.getStatsForDate(today);
            if (todayStats) {
              await storage.updateStats(today, {
                totalRevenue: (todayStats.totalRevenue || 0) + rental.price,
                successfulOrders: (todayStats.successfulOrders || 0) + 1
              });
            }

            res.json({
              status: "completed",
              account: {
                username: account.username,
                password: account.password,
                rentEnd: rentEnd.toISOString()
              }
            });
          }
        }
      } else {
        res.json({
          status: paymentInfo.data?.status || "pending"
        });
      }
    } catch (error) {
      console.error("Payment check error:", error);
      res.status(500).json({ message: "Lỗi kiểm tra thanh toán" });
    }
  });

  // Admin login
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);

      const admin = await storage.getAdminByUsername(username);
      if (!admin || admin.password !== password || !admin.isActive) {
        return res.status(401).json({ message: "Thông tin đăng nhập không chính xác" });
      }

      // In a real app, you would generate a JWT token here
      res.json({ 
        success: true,
        admin: {
          id: admin.id,
          username: admin.username
        }
      });
    } catch (error) {
      res.status(400).json({ message: "Dữ liệu không hợp lệ" });
    }
  });

  // Admin: Get dashboard stats
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const todayStats = await storage.getStatsForDate(today);
      
      const accounts = await storage.getAccounts();
      const activeAccounts = accounts.filter(acc => acc.status === "available").length;
      const totalAccounts = accounts.length;

      res.json({
        todayRevenue: todayStats?.totalRevenue || 0,
        successOrders: todayStats?.successfulOrders || 0,
        failedOrders: todayStats?.failedOrders || 0,
        activeAccounts: `${activeAccounts}/${totalAccounts}`
      });
    } catch (error) {
      res.status(500).json({ message: "Lỗi lấy thống kê" });
    }
  });

  // Admin: Manage accounts
  app.post("/api/admin/accounts", async (req, res) => {
    try {
      const accountData = insertAccountSchema.parse(req.body);
      const account = await storage.createAccount(accountData);
      res.json(account);
    } catch (error) {
      res.status(400).json({ message: "Lỗi tạo tài khoản" });
    }
  });

  app.delete("/api/admin/accounts/:id", async (req, res) => {
    try {
      const accountId = parseInt(req.params.id);
      const success = await storage.deleteAccount(accountId);
      if (success) {
        res.json({ success: true });
      } else {
        res.status(404).json({ message: "Không tìm thấy tài khoản" });
      }
    } catch (error) {
      res.status(500).json({ message: "Lỗi xóa tài khoản" });
    }
  });

  app.patch("/api/admin/accounts/:id", async (req, res) => {
    try {
      const accountId = parseInt(req.params.id);
      const updates = req.body;
      const account = await storage.updateAccount(accountId, updates);
      if (account) {
        res.json(account);
      } else {
        res.status(404).json({ message: "Không tìm thấy tài khoản" });
      }
    } catch (error) {
      res.status(500).json({ message: "Lỗi cập nhật tài khoản" });
    }
  });

  // Admin: Manage pricing
  app.patch("/api/admin/pricing/:packageType", async (req, res) => {
    try {
      const { packageType } = req.params;
      const { price } = req.body;
      
      const pricing = await storage.updatePricing(packageType, { price: parseInt(price) });
      if (pricing) {
        res.json(pricing);
      } else {
        res.status(404).json({ message: "Không tìm thấy gói giá" });
      }
    } catch (error) {
      res.status(500).json({ message: "Lỗi cập nhật giá" });
    }
  });

  // Admin: Manual password change
  app.post("/api/admin/accounts/:id/change-password", async (req, res) => {
    try {
      const accountId = parseInt(req.params.id);
      const account = await storage.getAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: "Không tìm thấy tài khoản" });
      }

      // Import the password change function
      const { changePassword, generateNewPassword } = await import("./lib/puppeteer");
      
      // Attempt to change password
      const result = await changePassword({
        id: account.id,
        username: account.username,
        password: account.password
      });

      if (result.success && result.newPassword) {
        // Update account with new password
        const updatedAccount = await storage.updateAccount(accountId, {
          password: result.newPassword,
          status: "available",
          rentedBy: null,
          rentStart: null,
          rentEnd: null,
          packageType: null
        });

        res.json({
          success: true,
          message: "Đã thay đổi mật khẩu thành công",
          newPassword: result.newPassword
        });
      } else {
        res.status(500).json({ message: "Không thể thay đổi mật khẩu" });
      }
    } catch (error) {
      console.error("Manual password change error:", error);
      res.status(500).json({ message: "Lỗi thay đổi mật khẩu" });
    }
  });

  // Test password change with real account
  app.post("/api/admin/test-password-change", async (req, res) => {
    try {
      console.log("🧪 Testing password change with real account nhungcamcu...");
      
      const testAccount = {
        id: 999,
        username: "nhungcamcu",
        password: "thuevip.com2509"
      };

      const newPassword = `newpass${Date.now()}`;
      console.log(`🔄 Attempting to change password for ${testAccount.username} to: ${newPassword}`);
      
      const result = await changePassword(testAccount, newPassword);

      console.log("📊 Password change result:", result);

      res.json({ 
        success: result.success,
        message: result.success 
          ? `✅ Thành công! Đã đổi mật khẩu cho ${testAccount.username} thành: ${result.newPassword}` 
          : `❌ Thất bại: Không thể đổi mật khẩu cho ${testAccount.username}`,
        oldPassword: testAccount.password,
        newPassword: result.newPassword || null,
        testAccount: testAccount.username,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("❌ Real password change test error:", error);
      res.status(500).json({ 
        success: false,
        error: "Internal server error",
        message: "❌ Lỗi hệ thống khi test đổi mật khẩu"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
