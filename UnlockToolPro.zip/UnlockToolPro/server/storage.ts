import { accounts, rentals, admins, pricing, stats, type Account, type InsertAccount, type Rental, type InsertRental, type Admin, type InsertAdmin, type Pricing, type InsertPricing, type Stats } from "@shared/schema";
import { drizzle } from "drizzle-orm/node-postgres";
import { eq, and, gte, lte, desc } from "drizzle-orm";
import pkg from 'pg';
const { Pool } = pkg;

const connectionString = process.env.DATABASE_URL || "mongodb+srv://nhungcamcu:Taivu14062001@cluster0.svcshml.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

// For development, we'll use in-memory storage
// In production, you would connect to MongoDB Atlas
export interface IStorage {
  // Account methods
  getAccounts(): Promise<Account[]>;
  getAccount(id: number): Promise<Account | undefined>;
  getAvailableAccounts(): Promise<Account[]>;
  getRentedAccounts(): Promise<Account[]>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: number, updates: Partial<Account>): Promise<Account | undefined>;
  deleteAccount(id: number): Promise<boolean>;

  // Rental methods
  getRentals(): Promise<Rental[]>;
  getRental(id: number): Promise<Rental | undefined>;
  getRentalByOrderCode(orderCode: string): Promise<Rental | undefined>;
  createRental(rental: InsertRental): Promise<Rental>;
  updateRental(id: number, updates: Partial<Rental>): Promise<Rental | undefined>;

  // Admin methods
  getAdminByUsername(username: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;

  // Pricing methods
  getPricing(): Promise<Pricing[]>;
  getPricingByPackage(packageType: string): Promise<Pricing | undefined>;
  updatePricing(packageType: string, updates: Partial<Pricing>): Promise<Pricing | undefined>;

  // Stats methods
  getStatsForDate(date: string): Promise<Stats | undefined>;
  updateStats(date: string, updates: Partial<Stats>): Promise<Stats>;
}

export class MemStorage implements IStorage {
  private accounts: Map<number, Account>;
  private rentals: Map<number, Rental>;
  private admins: Map<number, Admin>;
  private pricingMap: Map<string, Pricing>;
  private statsMap: Map<string, Stats>;
  private currentAccountId: number;
  private currentRentalId: number;
  private currentAdminId: number;

  constructor() {
    this.accounts = new Map();
    this.rentals = new Map();
    this.admins = new Map();
    this.pricingMap = new Map();
    this.statsMap = new Map();
    this.currentAccountId = 1;
    this.currentRentalId = 1;
    this.currentAdminId = 1;

    this.initializeData();
  }

  private async initializeData() {
    // Create admin user
    const admin: Admin = {
      id: this.currentAdminId++,
      username: "nhungcamcu",
      password: "Taivu14062001",
      isActive: true,
      createdAt: new Date()
    };
    this.admins.set(admin.id, admin);

    // Create sample accounts
    const sampleAccounts = [
      "unlockuser001", "unlockuser002", "unlockuser003", "unlockuser004", "unlockuser005",
      "unlockuser006", "unlockuser007", "unlockuser008", "unlockuser009", "unlockuser010"
    ];

    for (const username of sampleAccounts) {
      const account: Account = {
        id: this.currentAccountId++,
        username,
        password: "thuetool.online001",
        status: "available",
        rentedBy: null,
        rentStart: null,
        rentEnd: null,
        packageType: null,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      this.accounts.set(account.id, account);
    }

    // Initialize pricing
    const defaultPricing = [
      { packageType: "6h", price: 16000, duration: 6, displayName: "6 giờ" },
      { packageType: "12h", price: 22000, duration: 12, displayName: "12 giờ" },
      { packageType: "1d", price: 32000, duration: 24, displayName: "1 ngày" },
      { packageType: "3d", price: 72000, duration: 72, displayName: "3 ngày" },
      { packageType: "7d", price: 102000, duration: 168, displayName: "7 ngày" }
    ];

    for (const pricing of defaultPricing) {
      const pricingItem: Pricing = {
        id: Math.floor(Math.random() * 1000000),
        ...pricing,
        updatedAt: new Date()
      };
      this.pricingMap.set(pricing.packageType, pricingItem);
    }

    // Initialize today's stats
    const today = new Date().toISOString().split('T')[0];
    const todayStats: Stats = {
      id: 1,
      date: today,
      totalRevenue: 0,
      successfulOrders: 0,
      failedOrders: 0,
      updatedAt: new Date()
    };
    this.statsMap.set(today, todayStats);
  }

  async getAccounts(): Promise<Account[]> {
    return Array.from(this.accounts.values());
  }

  async getAccount(id: number): Promise<Account | undefined> {
    return this.accounts.get(id);
  }

  async getAvailableAccounts(): Promise<Account[]> {
    return Array.from(this.accounts.values()).filter(account => account.status === "available");
  }

  async getRentedAccounts(): Promise<Account[]> {
    return Array.from(this.accounts.values()).filter(account => 
      account.status === "rented" || account.status === "processing_payment"
    );
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const id = this.currentAccountId++;
    const account: Account = {
      id,
      username: insertAccount.username,
      password: insertAccount.password,
      status: insertAccount.status || "available",
      rentedBy: insertAccount.rentedBy || null,
      rentStart: insertAccount.rentStart || null,
      rentEnd: insertAccount.rentEnd || null,
      packageType: insertAccount.packageType || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.accounts.set(id, account);
    return account;
  }

  async updateAccount(id: number, updates: Partial<Account>): Promise<Account | undefined> {
    const account = this.accounts.get(id);
    if (!account) return undefined;

    const updatedAccount = {
      ...account,
      ...updates,
      updatedAt: new Date()
    };
    this.accounts.set(id, updatedAccount);
    return updatedAccount;
  }

  async deleteAccount(id: number): Promise<boolean> {
    return this.accounts.delete(id);
  }

  async getRentals(): Promise<Rental[]> {
    return Array.from(this.rentals.values());
  }

  async getRental(id: number): Promise<Rental | undefined> {
    return this.rentals.get(id);
  }

  async getRentalByOrderCode(orderCode: string): Promise<Rental | undefined> {
    return Array.from(this.rentals.values()).find(rental => rental.paymentOrderCode === orderCode);
  }

  async createRental(insertRental: InsertRental): Promise<Rental> {
    const id = this.currentRentalId++;
    const rental: Rental = {
      id,
      accountId: insertRental.accountId,
      packageType: insertRental.packageType,
      price: insertRental.price,
      paymentStatus: insertRental.paymentStatus || "pending",
      paymentOrderCode: insertRental.paymentOrderCode || null,
      paymentUrl: insertRental.paymentUrl || null,
      rentStart: insertRental.rentStart || null,
      rentEnd: insertRental.rentEnd || null,
      customerInfo: insertRental.customerInfo || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.rentals.set(id, rental);
    return rental;
  }

  async updateRental(id: number, updates: Partial<Rental>): Promise<Rental | undefined> {
    const rental = this.rentals.get(id);
    if (!rental) return undefined;

    const updatedRental = {
      ...rental,
      ...updates,
      updatedAt: new Date()
    };
    this.rentals.set(id, updatedRental);
    return updatedRental;
  }

  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    return Array.from(this.admins.values()).find(admin => admin.username === username);
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const id = this.currentAdminId++;
    const admin: Admin = {
      id,
      username: insertAdmin.username,
      password: insertAdmin.password,
      isActive: insertAdmin.isActive !== undefined ? insertAdmin.isActive : true,
      createdAt: new Date()
    };
    this.admins.set(id, admin);
    return admin;
  }

  async getPricing(): Promise<Pricing[]> {
    return Array.from(this.pricingMap.values());
  }

  async getPricingByPackage(packageType: string): Promise<Pricing | undefined> {
    return this.pricingMap.get(packageType);
  }

  async updatePricing(packageType: string, updates: Partial<Pricing>): Promise<Pricing | undefined> {
    const pricing = this.pricingMap.get(packageType);
    if (!pricing) return undefined;

    const updatedPricing = {
      ...pricing,
      ...updates,
      updatedAt: new Date()
    };
    this.pricingMap.set(packageType, updatedPricing);
    return updatedPricing;
  }

  async getStatsForDate(date: string): Promise<Stats | undefined> {
    return this.statsMap.get(date);
  }

  async updateStats(date: string, updates: Partial<Stats>): Promise<Stats> {
    const existingStats = this.statsMap.get(date);
    if (existingStats) {
      const updatedStats = {
        ...existingStats,
        ...updates,
        updatedAt: new Date()
      };
      this.statsMap.set(date, updatedStats);
      return updatedStats;
    } else {
      const newStats: Stats = {
        id: Math.floor(Math.random() * 1000000),
        date,
        totalRevenue: 0,
        successfulOrders: 0,
        failedOrders: 0,
        ...updates,
        updatedAt: new Date()
      };
      this.statsMap.set(date, newStats);
      return newStats;
    }
  }
}

// Tạm thời dùng memory storage, sau sẽ chuyển sang MongoDB khi URI được cấu hình đúng
export const storage = new MemStorage();
