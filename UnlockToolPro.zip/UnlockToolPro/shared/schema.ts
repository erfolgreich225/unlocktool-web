import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  status: text("status").notNull().default("available"), // available, rented, processing_payment
  rentedBy: text("rented_by"),
  rentStart: timestamp("rent_start"),
  rentEnd: timestamp("rent_end"),
  packageType: text("package_type"), // 6h, 12h, 1d, 3d, 7d
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const rentals = pgTable("rentals", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").notNull(),
  packageType: text("package_type").notNull(),
  price: integer("price").notNull(),
  paymentStatus: text("payment_status").notNull().default("pending"), // pending, completed, failed, expired
  paymentOrderCode: text("payment_order_code"),
  paymentUrl: text("payment_url"),
  rentStart: timestamp("rent_start"),
  rentEnd: timestamp("rent_end"),
  customerInfo: json("customer_info"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const pricing = pgTable("pricing", {
  id: serial("id").primaryKey(),
  packageType: text("package_type").notNull().unique(),
  price: integer("price").notNull(),
  duration: integer("duration").notNull(), // in hours
  displayName: text("display_name").notNull(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const stats = pgTable("stats", {
  id: serial("id").primaryKey(),
  date: text("date").notNull().unique(), // YYYY-MM-DD format
  totalRevenue: integer("total_revenue").default(0),
  successfulOrders: integer("successful_orders").default(0),
  failedOrders: integer("failed_orders").default(0),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertRentalSchema = createInsertSchema(rentals).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertAdminSchema = createInsertSchema(admins).omit({
  id: true,
  createdAt: true
});

export const insertPricingSchema = createInsertSchema(pricing).omit({
  id: true,
  updatedAt: true
});

export const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1)
});

export const rentalRequestSchema = z.object({
  accountId: z.number(),
  packageType: z.enum(["6h", "12h", "1d", "3d", "7d"])
});

export type Account = typeof accounts.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type Rental = typeof rentals.$inferSelect;
export type InsertRental = z.infer<typeof insertRentalSchema>;
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type Pricing = typeof pricing.$inferSelect;
export type InsertPricing = z.infer<typeof insertPricingSchema>;
export type Stats = typeof stats.$inferSelect;
export type LoginRequest = z.infer<typeof loginSchema>;
export type RentalRequest = z.infer<typeof rentalRequestSchema>;
